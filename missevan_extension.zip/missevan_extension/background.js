chrome.runtime.onInstalled.addListener(() => {
  console.log("Missevan Downloader Extension installed.");
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'download') {
    chrome.downloads.download({
      url: msg.url,
      filename: msg.filename,
      saveAs: false
    });
  }
  if (msg.action === 'notify') {
    chrome.notifications.create({
      type: 'basic',
      iconUrl: 'icon48.png',
      title: msg.title,
      message: msg.message
    });
  }
});
